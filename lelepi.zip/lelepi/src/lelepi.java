//Név: Róth József
//Csoport: I/1/N
//Dátum: 2023.04.27.

import java.util.Scanner;

public class lelepi {
    
    public static double calculateVolume(double a, double b, double c) {
        return a * b * c;
    }

    public static boolean validateInput(double a, double b, double c) {
        return a > 0 && b > 0 && c > 0;
    }

    public static void main(String[] args) {

        System.out.println("Név: Róth Jószef");
        System.out.println("Csoport: SZOFT I/1/N");
        System.out.println("Dátum: 2023.04.27.");

        Scanner scanner = new Scanner(System.in);
        System.out.print("Adja meg az a oldal hosszát: ");
        double a = scanner.nextDouble();
        System.out.print("Adja meg a b oldal hosszát: ");
        double b = scanner.nextDouble();
        System.out.print("Adja meg a c oldal hosszát: ");
        double c = scanner.nextDouble();
        scanner.close();

        double volume = calculateVolume(a, b, c);
        System.out.println("A paralelepipedon térfogata: " + volume);
    }
}

