//Név: Róth József
//Csoport: I/1/N
//Dátum: 2023.04.27.

public class lelepiTest {

    @Test
    public void testCalculateVolume() {
        double a = 2.0;
        double b = 3.0;
        double c = 4.0;
        double expectedVolume = 24.0;
        double actualVolume = lelepi.calculateVolume(a, b, c);
        assertEquals(expectedVolume, actualVolume);
    }

    private void assertEquals(double expectedVolume, double actualVolume) {
    }
}